# 外卖经营复盘专家

一个可安装到 WorkBuddy 的外卖经营分析专家。它读取用户上传的 Excel、CSV 或 JSON，在不连接外卖平台接口的情况下，完成数据校验、重点门店定位、规则证据追溯和候选任务生成。

适用于一个品牌有多个门店、每个门店同时经营美团外卖、淘宝闪购（饿了么）和京东外卖的场景。分析粒度始终保留为“品牌 + 门店 + 平台 + 周期”。

## 它解决什么问题

- 先检查缺字段、重复数据、周期不可比、0 值语义不明等问题，避免带病分析。
- 将收入变化拆成订单和收入客单贡献，不凭单一结果指标猜原因。
- 分平台识别曝光、进店、下单、新老客、服务和连续下滑等经营信号。
- 把建议变成有负责人、证据要求、观察周期和验证指标的候选任务。
- 强制保留人工确认，不自动操作平台、不自动联系顾客。

## 快速体验

```bash
node examples/generate-demo-input.mjs
node skills/takeout-business-review/scripts/run_takeout_review.mjs \
  --input examples/synthetic-input.json \
  --output-dir outputs/demo
```

演示数据包含 2 个虚构品牌、3 个虚构门店、3 个平台和 3 个连续周期，共 27 行。所有名称和数字均为合成数据。

## 安装到 WorkBuddy

1. 下载 `releases/takeout-business-review-expert-v1.0.1.zip`。
2. 在 WorkBuddy 的“专家·技能·连接器”中进入“我的专家”。
3. 选择导入专家并上传 ZIP 包。
4. 召唤“外卖经营复盘专家”，上传经营数据后输入“分析我的外卖经营数据并生成经营复盘”。

## 仓库结构

```text
.codebuddy-plugin/       WorkBuddy 专家元数据
agents/                  专家角色与交互边界
avatars/                 女性运营分析专家头像
skills/                  规则、动作库、脚本和工作簿模板
examples/                完全虚构的演示输入
docs/                    产品设计、架构和隐私说明
tests/                   无外部依赖的冒烟测试
.github/workflows/       GitHub Actions 自动检查
```

## 测试

```bash
node tests/public-smoke-test.mjs
```

测试覆盖元数据、文件结构、27 行多品牌多门店三平台输入、结果文件生成、重点门店和候选任务，以及禁止输出的高风险动作。

## 方法与边界

规则库中的 20%、2500 元、4.6 分等阈值是为了展示工作流而提供的可配置默认值，不是美团、淘宝闪购（饿了么）或京东外卖的官方标准。详见 [公开方法说明](docs/public-methodology.md)。

本项目是个人 AI 工作流原型，不属于、也不代表任何外卖平台。它不连接或操作平台，不自动执行运营动作，不在证据不足时生成确定性归因。使用真实经营数据前，请先完成脱敏和权限确认。

## 作者

Argine

## License

MIT
